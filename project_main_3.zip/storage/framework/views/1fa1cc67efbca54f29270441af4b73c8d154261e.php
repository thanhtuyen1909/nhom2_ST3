
<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <!-- row -->
    <div class="row tm-content-row">
        <div class="col-12 tm-block-col">
            <div class="tm-bg-primary-dark tm-block tm-block-h-auto">
                <h2 class="tm-block-title">Danh sách bình luận</h2>
                <div class="tm-product-table-container">
                    <table class="table table-hover tm-table-small tm-product-table">
                        <thead>
                            <tr>
                                <th scope="col">&nbsp;</th>
                                <th scope="col">Tên người gửi</th>
                                <th scope="col">Bình luận</th>
                                <th scope="col">Ngày gửi</th>
                                <th scope="col">Sản phẩm</th>
                                <th scope="col">Quản lý</th>
                            </tr>
                        </thead>
                        <tbody id="comment-body">
                            <?php $__currentLoopData = $data['comment']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($comment->parent_id == 0): ?>
                            <tr>
                                <th scope="row"><input type="checkbox" /></th>
                                <td><?= $comment->linkUser['name'] ?></td>
                                <td><?php echo e($comment->comment); ?> <br>
                                    <ul style="list-style-type: decimal;">
                                        Trả lời:
                                        <?php $__currentLoopData = $data['comment']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $comm_reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($comm_reply->parent_id == $comment->id): ?>
                                        <li><?php echo e($comm_reply->comment); ?>

                                            <a onclick="deleteComment(<?= $comm_reply->id ?>)" href="javascript:" style="width: 20px;">
                                                <i class="far fa-trash-alt tm-product-delete-icon" style="font-size: 1rem;"></i>
                                            </a>
                                        </li>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                    <form action="#">
                                        <?php echo csrf_field(); ?>
                                        <textarea class="form-control comment-content-reply-<?= $comment->id ?>" col="" rows="3"></textarea> <br>
                                        <button class="btn-sm" onclick="getReply(<?= $comment->id ?>, <?= $comment->idSP ?>)">Trả lời bình luận</button>
                                    </form>
                                </td>
                                <td><?php echo e($comment->created_at); ?></td>
                                <td><?= $comment->linkProduct['name'] ?></td>
                                <td>
                                    <a onclick="deleteComment(<?= $comment->id ?>)" href="javascript:" class="tm-product-delete-link">
                                        <i class="far fa-trash-alt tm-product-delete-icon"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <!-- table container -->
                <button class="btn btn-primary btn-block text-uppercase">
                    XOÁ BÌNH LUẬN ĐƯỢC CHỌN
                </button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\project_8\resources\views/admin/pages/commentManager.blade.php ENDPATH**/ ?>