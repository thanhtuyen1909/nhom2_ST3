
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="section-title">
                <h2>KẾT QUẢ TÌM KIẾM</h2>
            </div>
        </div>
    </div>
    <div class="row">
        <?php if(isset($data)): ?>
        <?php $__currentLoopData = $data['product1']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-4 col-md-6 col-sm-6">
            <div class="product__item">
                <div class="product__item__pic set-bg" data-setbg="img/image_sql/products/<?= $value->filename ?>" style="height: 320px; background-size: cover; background-position: center;"> 
                    <?php if($value->sale > 0): ?>
                    <div class="product__discount__percent">-<?php echo e($value->sale); ?>%</div>
                    <?php endif; ?>
                    <ul class="product__item__pic__hover">
                        <li><a href="#"><i class="fa fa-heart"></i></a></li>
                        <li><a href="#"><i class="fa fa-retweet"></i></a></li>
                        <li><a onclick="AddCart(<?= $value->id ?>)" href="javascript:"><i class="fa fa-shopping-cart"></i></a></li>
                    </ul>
                </div>
                <div class="product__item__text">
                    <h6><a href="<?php echo e(URL::to('/')); ?>/shop-details/<?php echo e($value->id); ?>"> <?php echo e($value->name); ?></a></h6>
                    <h5><?= number_format($value->price) ?> VND</h5>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\project_main_1\resources\views/pages/search.blade.php ENDPATH**/ ?>