
<?php $__env->startSection('content'); ?>
<div class="container">
    <form class="form" id="login" method="POST" action="login.php">
        <h1 class="form__title">Đăng nhập</h1>
        <div class="form__message form__message--error"></div>
        <div class="form__input-group">
            <input type="text" name="username" class="form__input" autofocus placeholder="Username">
            <div class="form__input-error-message"></div>
        </div>
        <div class="form__input-group">
            <input type="password" name="password" class="form__input" autofocus placeholder="Password">
            <div class="form__input-error-message"></div>
        </div>
        <button class="form__button" type="submit" name="submit">Continue</button>
        <p class="form__text">
            Bạn chưa có tài khoản? <a class="form__link" href="<?php echo e(url('/register')); ?>" id="linkCreateAccount">Tạo tài khoản</a>
        </p>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.layout-login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\nhom2_ST3_1\resources\views/pages/login.blade.php ENDPATH**/ ?>