<?php echo e($slot); ?>

<?php /**PATH C:\wamp64\www\project_nhom2_ST3_main\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>