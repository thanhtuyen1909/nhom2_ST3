<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td class="tm-product-name"><?php echo e($users->name); ?></td>
    <td><?php echo e($users->email); ?></td>
    <td><?php echo e($users->role_name); ?></td>
    <td><?php echo e($users->created_at); ?></td>
    <td><?php echo e($users->updated_at); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\wamp64\www\project_main_2\resources\views/admin/pages/listAccount.blade.php ENDPATH**/ ?>