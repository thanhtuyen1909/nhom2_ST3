<div class="row">
    <?php if(count($data['favourite']) > 0): ?>
    <?php $__currentLoopData = $data['favourite']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-lg-3 col-md-4 col-sm-6">
        <div class="product__item">
            <div class="product__item__pic set-bg">
                <img src="<?php echo e(URL::to('/')); ?>/img/image_sql/products/<?= $item->filename ?>" alt="">
                <ul class="product__item__pic__hover">
                <?php $temp = false; ?>
                            <?php $__currentLoopData = $data['check']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $check): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($check == $item->id): ?>
                            <li id="favourite<?= $item->id ?>"><a  onclick="AddFavourite(<?= $item->id ?>)" href="javascript:" style="background-color: #7fad39;"><i class="fa fa-heart"></i></a></li>
                            <?php $temp = true; ?>
                            <?php break; ?>;
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($temp == false): ?>
                            <li><a id="favourite<?= $item->id ?>" onclick="AddFavourite(<?= $item->id ?>)" href="javascript:"><i class="fa fa-heart"></i></a></li>
                            <?php endif; ?>
                            <li><a href="javascript:"><i class="fa fa-retweet"></i></a></li>

                            <li><a onclick="AddCart(<?= $item->id ?>,1)" href="javascript:"><i class="fa fa-shopping-cart"></i></a></li>

                </ul>
            </div>
            <div class="product__item__text">
                <h6><a href="./shop-details/<?php echo e($item->id); ?>"><?php echo e($item->name); ?></a></h6>
                <h5><?php echo e(number_format($item->price)); ?> VND</h5>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
    <span> Không có sản phâm yêu thích </span>
    <?php endif; ?>
</div><?php /**PATH C:\wamp64\www\project_1\resources\views//pages/listFavourite.blade.php ENDPATH**/ ?>