
<?php $__env->startSection('content'); ?>
<div class="container tm-mt-big tm-mb-big">
  <div class="row">
    <div class="col-xl-9 col-lg-10 col-md-12 col-sm-12 mx-auto">
      <div class="tm-bg-primary-dark tm-block tm-block-h-auto">
        <div class="row">
          <div class="col-12">
            <h2 class="tm-block-title d-inline-block">Chỉnh sửa thông tin sản phẩm</h2>
          </div>
        </div>
        <form action="<?php echo e(URL::to('/')); ?>/admin/upload/<?php echo e($data['product1'][0]->id); ?>" method="post" class="tm-edit-product-form" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <div class="row tm-edit-product-row">
            <div class="col-xl-6 col-lg-6 col-md-12">
              <div class="form-group mb-3">
                <label for="name">Tên sản phẩm
                </label>
                <input id="name" name="name" type="text" value="<?php echo e($data['product1'][0]->name); ?>" class="form-control validate" />
              </div>
              <div class="form-group mb-3">
                <label for="description">Mô tả</label>
                <textarea class="form-control validate tm-small" name="description" rows="4" required><?php echo e($data['product1'][0]->description); ?></textarea>
              </div>
              <div class="form-group mb-3">
                <label for="information">Giới thiệu</label>
                <textarea class="form-control validate tm-small" name="information" rows="4" required><?php echo e($data['product1'][0]->information); ?></textarea>
              </div>
              <div class="form-group mb-3">
                <label for="type_id">Loại sản phẩm</label>
                <select class="custom-select tm-select-accounts" id="type_id" name="type_id">
                  <option value="<?php echo e($data['product1'][0]->type_id); ?>" selected><?php echo e($data['product1'][0]->type_name); ?></option>
                  <?php $__currentLoopData = $data['protype']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($item->type_name !== $data['product1'][0]->type_name): ?>
                  <option value="<?php echo e($item->type_id); ?>"><?php echo e($item->type_name); ?></option>
                  <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="row">
                <div class="form-group mb-3 col-xs-12 col-sm-6">
                  <label for="created_at">Ngày nhập
                  </label>
                  <input readonly id="created_at" name="created_at" type="text" value="<?php echo e(date('d-m-Y', strtotime($data['product1'][0]->created_at))); ?>" class="form-control validate" data-large-mode="true" />
                </div>
                <div class="form-group mb-3 col-xs-12 col-sm-6">
                  <label for="weight">Cân nặng
                  </label>
                  <input id="weight" name="weight" type="text" value="<?php echo e($data['product1'][0]->weight); ?>" class="form-control validate" />
                </div>
              </div>
              <div class="row">
                <div class="form-group mb-3 col-xs-12 col-sm-6">
                  <label for="feature">Nổi bật</label>
                  <select class="custom-select tm-select-accounts" id="feature" name="feature">
                    <?php if($data['product1'][0]->feature == 1): ?>
                    <option value="1" selected>Nổi bật</option>
                    <option value="0">Không</option>
                    <?php else: ?>
                    <option value="1">Nổi bật</option>
                    <option value="0" selected>Không</option>
                    <?php endif; ?>

                  </select>
                </div>
                <div class="form-group mb-3 col-xs-12 col-sm-6">
                  <label for="sale">Giảm giá
                  </label>
                  <input id="sale" name="sale" type="text" value="<?php echo e($data['product1'][0]->sale); ?>" class="form-control validate" />
                </div>
              </div>
              <div class="row">
                <div class="form-group mb-3 col-xs-12 col-sm-6">
                  <label for="amount">Số lượng
                  </label>
                  <input id="amount" name="amount" type="text" value="<?php echo e($data['product1'][0]->amount); ?>" class="form-control validate" />
                </div>
                <div class="form-group mb-3 col-xs-12 col-sm-6">
                  <label for="price">Giá
                  </label>
                  <input id="price" name="price" value="<?php echo e($data['product1'][0]->price); ?>" class="form-control validate" />
                </div>
              </div>

            </div>
            <div class="col-xl-6 col-lg-6 col-md-12 mx-auto mb-4">
              <div class="tm-product-img-edit mx-auto">
                  <?php $check = false ?>
                  <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($photo->photo_feature == 1): ?>
                  <?php $check = true ?>
                  <img id="imgUpload" src="<?php echo e(URL::to('/')); ?>/img/image_sql/products/<?php echo e($photo->filename); ?>" alt="Product image" class="img-fluid d-block mx-auto">
                  <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php if($check == false): ?>
                  <img id="imgUpload" src="" alt="Product image" class="img-fluid d-block mx-auto">
                  <?php endif; ?>
              </div>
              <div class="tm-product-img-edit mx-auto">
                <div class="imgPreview">
                  <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($photo->photo_feature == 0): ?>
                  <img src="<?php echo e(URL::to('/')); ?>/img/image_sql/products/<?php echo e($photo->filename); ?>" alt="">
                  <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              </div>
              <div class="custom-file mt-3 mb-3">
                <input id="fileInput" name="fileInput" type="file" style="display:none;" onchange="readURL(this);" />
                <input class="btn btn-primary btn-block mx-auto" value="CHỌN ẢNH ĐẠI DIỆN" onclick="document.getElementById('fileInput').click();" />
                <input id="images" class="btn btn-primary btn-block mx-auto" value="CHỌN ẢNH" name="imageFile[]" type="file" multiple="multiple" />
              </div>
            </div>
            <div class="col-12">
              <button type="submit" class="btn btn-primary btn-block text-uppercase">Cập nhật</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\project_main_1\resources\views/admin/pages/edit-product.blade.php ENDPATH**/ ?>