
<?php $__env->startSection('content'); ?>
<div class="container mt-5">
  <div class="row tm-content-row">
    <div class="col-12 tm-block-col">
      <div class="tm-bg-primary-dark tm-block tm-block-h-auto">
        <h2 class="tm-block-title">Danh sách quyền</h2>
        <p class="text-white">Accounts</p>
        <?php
        $roles = DB::table('roles')->get();
        ?>
        <select class="custom-select" id="select_id" onchange="roleChange()">
          <option value="0">-- Chọn quyền --</option>
          <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($role->role_id); ?>"><?php echo e($role->role_name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
    </div>
  </div>
  <!-- row -->
  <div class="row tm-content-row">
    <div class="col-12 tm-block-col">
      <div class="tm-bg-primary-dark tm-block tm-block-h-auto">
      <h2 class="tm-block-title">Danh sách tài khoản</h2>
        <div class="tm-product-table-container">
          <table class="table table-hover tm-table-small tm-product-table">
            <thead>
              <tr>
                <th scope="col">USERNAME</th>
                <th scope="col">EMAIL</th>
                <th scope="col">ROLE</th>
                <th scope="col">UPDATED AT</th>
                <th scope="col">CREATED AT</th>
              </tr>
            </thead>
            <tbody id="account-body">
              <?php
              $user = DB::table('users')->join('roles', 'users.role_id', '=', 'roles.role_id')->orderByDesc('users.id', 'desc')->get();
              ?>
              
              <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td class="tm-product-name" data-id="<?php echo e($users->id); ?>"><?php echo e($users->name); ?></td>
                <td><?php echo e($users->email); ?></td>
                <td><?php echo e($users->role_name); ?></td>
                <td><?php echo e($users->created_at); ?></td>
                <td><?php echo e($users->updated_at); ?></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
        <!-- table container -->
        <a href="<?php echo e(url('/admin/add-account')); ?>" class="btn btn-primary btn-block text-uppercase mb-3">THÊM TÀI KHOẢN MỚI</a>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\project_main_3\resources\views/admin/pages/accountManage.blade.php ENDPATH**/ ?>