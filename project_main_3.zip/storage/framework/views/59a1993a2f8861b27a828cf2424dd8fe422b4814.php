<?php $__currentLoopData = $data['protype']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td style="padding-top: 20px;" class="tm-product-name" data-id="<?php echo e($item->type_id); ?>"><?php echo e($item->type_name); ?></td>
    <td class="text-center">
        <a onclick="deleteProtype(<?= $item->type_id ?>)" href="javascript:" class="tm-product-delete-link">
            <i class="far fa-trash-alt tm-product-delete-icon"></i>
        </a>
    </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\wamp64\www\project_main\resources\views/admin/pages/listProtype.blade.php ENDPATH**/ ?>