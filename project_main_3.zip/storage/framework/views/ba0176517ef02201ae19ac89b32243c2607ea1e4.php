
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row profile-content">
        <div class="col-lg-7">
            <div class="card-body border">
                <h3 class="profile-tittle">THÔNG TIN TÀI KHOẢN</h3>
                <form method="post" action="<?php echo e(route('user.profile.update',$profile->id)); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="card-body-image">
                                <div class="image">
                                    <img id="imgUpload" src="<?php echo e(URL::to('/')); ?>/img/image_sql/img_users/<?php echo e($profile->image); ?>" alt="profile picture" class="img-fluid d-block mx-auto" style="width: 150px">
                                </div>
                                <div class="custom-image">
                                    <input id="fileInput" name="fileInput" type="file" style="display:none;" onchange="readURL(this);" />
                                    <input class="btn btn-success btn-sm" value="ĐỔI ẢNH" onclick="document.getElementById('fileInput').click();" style="margin: 15px 0 0 15px; width: 150px" />
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <label for="inputTitle" class="col-form-label">Tên người dùng</label>
                                <input id="inputTitle" type="text" name="name" placeholder="Enter name" value="<?php echo e($profile->name); ?>" class="form-control">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label for="inputEmail" class="col-form-label">Địa chỉ email</label>
                                <input id="inputEmail" disabled type="email" name="email" placeholder="Enter email" value="<?php echo e($profile->email); ?>" class="form-control">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <button type="submit" class="btn btn-success btn-sm">UPDATE</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="col-lg-5">
            <div class="card-body">
                <h3 class="profile-tittle-1">THÔNG TIN LIÊN QUAN</h3>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\project_main_3\resources\views/pages/user/profile.blade.php ENDPATH**/ ?>