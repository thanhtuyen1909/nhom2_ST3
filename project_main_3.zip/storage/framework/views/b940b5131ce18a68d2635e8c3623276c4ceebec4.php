
<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row tm-content-row">
        <div class="col-sm-12 col-md-12 col-lg-8 col-xl-8 tm-block-col">
            <div class="tm-bg-primary-dark tm-block tm-block-products">
                <h2 class="tm-block-title">Mã đơn hàng: #<?php echo e($id); ?></h2>
                <div class="location-ship">
                    <p>Địa chỉ: <?php echo e($dataArray1[0]['diachi']); ?></p>
                    <p>Họ tên người nhận: <?php echo e($dataArray1[0]['hoten']); ?></p>
                    <p>Số điện thoại: <?php echo e($dataArray1[0]['sdt']); ?></p>
                    <p>Ghi chú: <?php echo e($dataArray1[0]['ghichu']); ?></p>
                </div>
                <div class="tm-product-table-container">
                    <table class="table table-hover tm-table-small tm-product-table">
                        <thead>
                            <tr>
                                <th scope="col" style="width: 50px;">&nbsp;</th>
                                <th scope="col" style="width: 250px; text-align: center">TÊN SẢN PHẨM</th>
                                <th scope="col" style="width: 80px; text-align: center">SỐ LƯỢNG</th>
                                <th scope="col" style="width: 80px; text-align: center">THÀNH TIỀN</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $dataArrayCTDH1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="product-img"><img src="<?php echo e(URL::to('/')); ?>/img/image_sql/products/<?= $value['photo'] ?>" alt="" style="width: 50px; height: 50px;"></td>
                                <td style="text-align: center"><?php echo e($value['nameSP']); ?></td>
                                <td style="text-align: center"><?php echo e($value['amount']); ?></td>
                                <td style="text-align: center"><?php echo e($value['price']); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <!-- table container -->
            </div>
        </div>
        <div class="col-sm-12 col-md-12 col-lg-4 col-xl-4 tm-block-col">
            <div class="tm-bg-primary-dark tm-block">
                <h2 class="tm-block-title">Khách hàng</h2>
                <div class="">
                    <div class="img-customer">
                        <img src="<?php echo e(URL::to('/')); ?>/img/image_sql/img_users/<?= $dataArray1[0]['userimg'] ?>" alt="" style="width: 200px; height: 200px;">
                    </div>
                    <p>Tên đăng nhập: <?php echo e($dataArray1[0]['username']); ?></p>
                    <p>Eamil: <?php echo e($dataArray1[0]['gmail']); ?></p>
                </div>
            </div>
            <?php
            $status = DB::table('status')->get();
            ?>
            <div class="tm-bg-primary-dark tm-block-1" style="margin-top: 25px">
                <h2 class="tm-block-title">Trạng thái</h2>
                <div class="tm-select-status">
                    <select class="custom-select" id="select_id" onchange="changeStatus()">
                        <option value="0">-- Chọn trạng thái --</option>
                        <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($value->status_id == $dataArray1[0]['status']): ?>
                        <option value="<?php echo e($value->status_id); ?>" selected><?php echo e($value->status_title); ?></option>
                        <?php else: ?>
                        <option value="<?php echo e($value->status_id); ?>"><?php echo e($value->status_title); ?></option>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-12" style="margin-top: 20px;">
                    <button type="submit" class="btn btn-primary btn-block text-uppercase" onclick="download()">IN PHIẾU</button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\project_main_2\resources\views/admin/pages/order-detail.blade.php ENDPATH**/ ?>