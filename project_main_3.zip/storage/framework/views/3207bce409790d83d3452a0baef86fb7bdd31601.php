
<?php $__env->startSection('content'); ?>
<!-- Breadcrumb Section Begin -->
<section class="breadcrumb-section set-bg" data-setbg="img/breadcrumb.jpg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="breadcrumb__text">
                    <h2>Lịch sử đơn hàng</h2>
                    <div class="breadcrumb__option">
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                        <span>Lịch sử đơn hàng</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Breadcrumb Section End -->

<!-- Shoping Cart Section Begin -->
<section class="shoping-cart spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-12" id="list-cart">
            <?php if(count($data['listOrder']) > 0): ?>
                <div class="shoping__cart__table">
                    <table>
                        <thead>
                            <tr>
                                <th class="shoping__product">Đơn hàng</th>
                                <th>Số lượng sản phẩm</th>
                                <th>Tổng tiền</th>
                                <th>Trạng thái</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data['listOrder']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="shoping__cart__item-1">
                                    <h5><a href="<?php echo e(URL::to('/')); ?>/order-details/<?php echo e($item->id); ?>"><?php echo e($item->id); ?></a></h5>
                                </td>
                                <td class="shoping__cart__price-1">
                                    <?php echo e($item->totalQuantity); ?>

                                </td>
                                <td class="shoping__cart__total-1">
                                <?= number_format($item->totalPrice)?> VND
                                </td>
                                <td class="shoping__cart__status">
                                    <?php echo e($item->status_title); ?>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="row">
                    <div class="col-lg-6">
                        <div class="shoping__cart__btns">
                            <a href="<?php echo e(url('/shop-grid')); ?>" class="primary-btn cart-btn">CONTINUE SHOPPING</a>
                        </div>
                    </div>
                </div>
                <?php else: ?>
                <div class="shoping__cart__table">
                    <div class="empty-cart">
                        <p>Chưa có đơn hàng</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6">
                        <div class="shoping__cart__btns">
                            <a href="<?php echo e(url('/shop-grid')); ?>" class="primary-btn cart-btn">CONTINUE SHOPPING</a>
                        </div>
                    </div>
                    
                </div>
                <?php endif; ?>

            </div>
        </div>
    </div>
</section>
<!-- Shoping Cart Section End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\project_8\resources\views/pages/listOrder.blade.php ENDPATH**/ ?>