
<?php $__env->startSection('content'); ?>
<!-- Breadcrumb Section Begin -->
<section class="breadcrumb-section set-bg" data-setbg="img/breadcrumb.jpg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="breadcrumb__text">
                    <h2>Favourite Product</h2>
                    <div class="breadcrumb__option">
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                        <span>Favourite Product</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Breadcrumb Section End -->

<!-- Shoping Cart Section Begin -->
<section class="shoping-cart spad">
    <div class="container" id="favourite">
        <div class="row" >
            <?php if(count($data['favourite']) > 0): ?>
            <?php $__currentLoopData = $data['favourite']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-4 col-sm-6">
                <div class="product__item">
                    <div class="product__item__pic set-bg" data-setbg="<?php echo e(URL::to('/')); ?>/img/image_sql/products/<?= $item->filename ?>">
                        <ul class="product__item__pic__hover">
                        <?php $temp = false; ?>
                            <?php $__currentLoopData = $data['check']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $check): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($check == $item->id): ?>
                            <li id="favourite<?= $item->id ?>"><a  onclick="AddFavourite(<?= $item->id ?>)" href="javascript:" style="background-color: #7fad39;"><i class="fa fa-heart"></i></a></li>
                            <?php $temp = true; ?>
                            <?php break; ?>;
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($temp == false): ?>
                            <li><a id="favourite<?= $item->id ?>" onclick="AddFavourite(<?= $item->id ?>)" href="javascript:"><i class="fa fa-heart"></i></a></li>
                            <?php endif; ?>
                            <li><a href="javascript:"><i class="fa fa-retweet"></i></a></li>

                            <li><a onclick="AddCart(<?= $item->id ?>,1)" href="javascript:"><i class="fa fa-shopping-cart"></i></a></li>

                        </ul>
                    </div>
                    <div class="product__item__text">
                        <h6><a href="./shop-details/<?php echo e($item->id); ?>"><?php echo e($item->name); ?></a></h6>
                        <h5><?php echo e(number_format($item->price)); ?> VND</h5>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <span> Không có sản phẩm yêu thích!!! </span>
            <?php endif; ?>
        </div>

    </div>
    </div>
</section>
<!-- Shoping Cart Section End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\project_3\resources\views/pages/favourite.blade.php ENDPATH**/ ?>