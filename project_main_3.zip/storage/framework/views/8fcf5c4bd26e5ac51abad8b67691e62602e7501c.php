
<?php $__env->startSection('content'); ?>
<!-- Breadcrumb Section Begin -->
<section class="breadcrumb-section set-bg" data-setbg="../img/breadcrumb.jpg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="breadcrumb__text">
                    <h2>Chi tiết đơn hàng</h2>
                    <div class="breadcrumb__option">
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                        <span>Chi tiết đơn hàng</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Breadcrumb Section End -->

<section class="shoping-cart spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-7">
                <h4>Địa chỉ nhận hàng</h4>
                <p style="padding-top: 30px;">Người đặt hàng: <?php echo e($thongTinNH[0]->hoten); ?></p>
                <p>Số điện thoại: <?php echo e($thongTinNH[0]->sdt); ?></p>
                <p>Địa chỉ: <?php echo e($thongTinNH[0]->diachi); ?></p>
                <p>Ghi chú: <?php echo e($thongTinNH[0]->ghichu); ?></p>
            </div>
            <div class="col-lg-5">
                <h4>Trạng thái đơn hàng</h4>
                <p class="status"><?php echo e($trangThaiDH[0]->status_title); ?></p>
            </div>
        </div>
    </div>
</section>

<!-- Shoping Cart Section Begin -->
<section class="shoping-cart spad" style="padding-top: 0;">
    <div class="container">
        <div class="row">
            <div class="col-lg-12" id="list-cart">
                <?php if(count($listOrderDetail) > 0): ?>
                <div class="shoping__cart__table">
                    <table>
                        <thead>
                            <tr>
                                <th></th>
                                <th class="shoping__product">Tên sản phẩm</th>
                                <th>Số lượng</th>
                                <th>Thành tiền</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php for($i=0; $i < count($listOrderDetail); $i++): ?> <tr>
                                <td>
                                    <img src="../img/image_sql/products/<?php echo e($photo_product[$i][0]->filename); ?>" alt="" style="width:100px; height:100px;">
                                </td>
                                <td class="shoping__cart__item-1">
                                    <h5><a href="<?php echo e(URL::to('/')); ?>/order-details/<?php echo e($listOrderDetail[$i]->idSP); ?>"><?php echo e($listOderDetailName[$i]); ?></a></h5>
                                </td>
                                <td class="shoping__cart__price-1">
                                    <?php echo e($listOrderDetail[$i]->soluong); ?>

                                </td>
                                <td class="shoping__cart__total-1">
                                    <?= number_format($listOrderDetail[$i]->thanhtien) ?> VND
                                </td>
                                </tr>
                                <?php endfor; ?>
                        </tbody>
                    </table>
                </div>
                <div class="row">
                    <div class="col-lg-6">
                        <div class="shoping__cart__btns">
                            <a href="<?php echo e(url('/shop-grid')); ?>" class="primary-btn cart-btn">CONTINUE SHOPPING</a>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="shoping__cart__btns" style="text-align: right;">
                            <a href="#" class="primary-btn cart-btn">REVIEW</a>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
<!-- Shoping Cart Section End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\project_6\resources\views/pages/order-details.blade.php ENDPATH**/ ?>