<?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $check = true ?>
<tr>
    <th scope="row" style="padding-top: 50px;"><input type="checkbox" /></th>
    <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($photo->product_id == $item->id && $photo->photo_feature == 1): ?>
    <?php $check = false ?>
    <td class="product-img"><img src="<?php echo e(URL::to('/')); ?>/img/image_sql/products/<?php echo e($photo->filename); ?>" alt="" style="width: 100px; height: 100px;"></td>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if($check == true): ?>
    <td class="product-img"><img src="" alt="" style="width: 100px; height: 100px;"></td>
    <?php endif; ?>
    <td class="tm-product-name" data-id="<?php echo e($item->id); ?>" style="padding-top: 50px;"><?php echo e($item->name); ?></td>
    <td style="padding-top: 50px;"><?php echo e(number_format($item->price)); ?></td>
    <td style="padding-top: 50px;"><?php echo e($item->type_name); ?></td>
    <td style="padding-top: 50px;"><?php echo e($item->amount); ?></td>
    <td style="padding-top: 40px;">
        <a onclick="deleteProduct(<?= $item->id ?>)" href="javascript:" class="tm-product-delete-link">
            <i class="far fa-trash-alt tm-product-delete-icon"></i>
        </a>
    </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\wamp64\www\nhom2_ST3_3\resources\views/admin/pages/listProduct.blade.php ENDPATH**/ ?>