<?php $__currentLoopData = $data['comment']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($comment->parent_id == 0): ?>
<tr>
    <th scope="row"><input type="checkbox" /></th>
    <td><?= $comment->linkUser['name'] ?></td>
    <td><?php echo e($comment->comment); ?> <br>
        <ul style="list-style-type: decimal;">
            Trả lời:
            <?php $__currentLoopData = $data['comment']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $comm_reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($comm_reply->parent_id == $comment->id): ?>
            <li><?php echo e($comm_reply->comment); ?>

                <a onclick="deleteComment(<?= $comm_reply->id ?>)" href="javascript:" style="width: 20px;">
                    <i class="far fa-trash-alt tm-product-delete-icon"></i>
                </a>
            </li>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <form action="#">
            <?php echo csrf_field(); ?>
            <textarea class="form-control comment-content-reply-<?= $comment->id ?>" id="" col="" rows="3"></textarea> <br>
            <button class="btn-sm" onclick="getReply(<?= $comment->id ?>, <?= $comment->idSP ?>)">Trả lời bình luận</button>
        </form>
    </td>
    <td><?php echo e($comment->created_at); ?></td>
    <td><?= $comment->linkProduct['name'] ?></td>
    <td>
        <a onclick="deleteComment(<?= $comment->id ?>)" href="javascript:" class="tm-product-delete-link">
            <i class="far fa-trash-alt tm-product-delete-icon"></i>
        </a>
    </td>
</tr>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\wamp64\www\project_main_2\resources\views/admin/pages/listComment.blade.php ENDPATH**/ ?>