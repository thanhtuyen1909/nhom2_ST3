<?php $__currentLoopData = $data['listContact']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <?php if($value->seen == 1): ?>
    <th scope="row"><input type="checkbox" id="checkContact" value="<?php echo e($value->id); ?>" checked /></th>
    <?php else: ?>
    <th scope="row"><input type="checkbox" id="checkContact" value="<?php echo e($value->id); ?>" /></th>
    <?php endif; ?>
    <td><?php echo e($value->tieude); ?></td>
    <td><?php echo e($value->noidung); ?></td>
    <td><?php echo e($value->hoten); ?></td>
    <td><?php echo e($value->email); ?></td>
    <td><?php echo e($value->sdt); ?></td>
    <td>
        <a href="#" class="tm-product-delete-link"><i class="far fa-trash-alt tm-product-delete-icon"></i>
        </a>
    </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\wamp64\www\project_7\resources\views/admin/pages/listContact1.blade.php ENDPATH**/ ?>