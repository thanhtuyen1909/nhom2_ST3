
<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row tm-content-row">
        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 tm-block-col">
            <div class="tm-bg-primary-dark tm-block tm-block-products">
                <h2 class="tm-block-title">Góp ý</h2>
                <div class="tm-product-table-container">
                    <table class="table table-hover tm-table-small tm-product-table">
                        <thead>
                            <tr>
                                <th scope="col">&nbsp;</th>
                                <th scope="col">TIÊU ĐỀ</th>
                                <th scope="col">NỘI DUNG</th>
                                <th scope="col">HỌ TÊN</th>
                                <th scope="col">EMAIL</th>
                                <th scope="col">SĐT</th>
                                <th scope="col">&nbsp;</th>
                            </tr>
                        </thead>
                        <tbody id="contact-body">
                            <?php $__currentLoopData = $data['listContact']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <?php if($value->seen == 1): ?>
                                <th scope="row"><input type="checkbox" id="checkContact<?=$value->id?>" onclick="checkSeen(<?=$value->id?>)" checked /></th>
                                <?php else: ?>
                                <th scope="row"><input type="checkbox" id="checkContact<?=$value->id?>" onclick="checkSeen(<?=$value->id?>)" /></th>
                                <?php endif; ?>
                                <td><?php echo e($value->tieude); ?></td>
                                <td><?php echo e($value->noidung); ?></td>
                                <td><?php echo e($value->hoten); ?></td>
                                <td><?php echo e($value->email); ?></td>
                                <td><?php echo e($value->sdt); ?></td>
                                <td>
                                    <a href="#" class="tm-product-delete-link"><i class="far fa-trash-alt tm-product-delete-icon"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\project_8\resources\views/admin/pages/listContact.blade.php ENDPATH**/ ?>