
<?php $__env->startSection('content'); ?>
<div class="container mt-5">
  <?php if(session()->has('success')): ?>
  <div class="alert alert-success alert-posifixed">
    <?php echo e(session()->get('success')); ?>

  </div>
  <?php endif; ?>
  <div class="row tm-content-row">
    <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 tm-block-col">
      <div class="tm-bg-primary-dark tm-block tm-block-products">
        <h2 class="tm-block-title">Danh sách banner chính</h2>
        <div class="tm-product-table-container">
          <table class="table table-hover tm-table-small tm-product-table">
            <thead>
              <tr>
                <th scope="col">&nbsp;</th>
                <th scope="col" style="width: 150px; text-align: center">HÌNH</th>
                <th scope="col" style="width: 150px; text-align: center">TIÊU ĐỀ PHỤ</th>
                <th scope="col" style="width: 150px; text-align: center">TIÊU ĐỀ</th>
                <th scope="col" style="width: 200px; text-align: center">MÔ TẢ</th>
                <th scope="col" style="width: 100px; text-align: center">STATUS</th>
                <th scope="col" style="text-align: center">NGÀY TẠO</th>
                <th scope="col" style="text-align: center">NGÀY SỬA</th>
                <th scope="col">&nbsp;</th>
                <th scope="col">&nbsp;</th>
              </tr>
            </thead>
            <tbody id="banner-hero-body">
              <?php if(count($banners) > 0): ?>
              <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($banner->position_id == 1): ?>
              <tr>
                <th scope="row" style="padding-top: 50px;"><input type="checkbox" /></th>
                <td class="product-img"><img src="<?php echo e(URL::to('/')); ?>/img/banner/<?= $banner->filename ?>" alt="" style="width: 100px; height: 100px;"></td>
                <td style="padding-top: 50px;"><?php echo e($banner->sub_title); ?></td>
                <td style="padding-top: 50px;"><?php echo e($banner->title); ?></td>
                <td style="padding-top: 50px;"><?php echo e($banner->description); ?></td>
                <td style="padding-top: 50px; text-align: center"><?php echo e($banner->status); ?></td>
                <td style="padding-top: 50px; text-align: center"><?php echo e($banner->created_at); ?></td>
                <td style="padding-top: 50px; text-align: center"><?php echo e($banner->updated_at); ?></td>
                <td style="padding-top: 40px;">
                  <a href="<?php echo e(URL::to('/')); ?>/admin/edit-banner/<?= $banner->id ?>" class="tm-product-delete-link">
                    <i class="fas fa-pen tm-product-delete-icon"></i>
                  </a>
                </td>
                <td style="padding-top: 40px;">
                  <a href="javascript:" class="tm-product-delete-link">
                    <i class="far fa-trash-alt tm-product-delete-icon"></i>
                  </a>
                </td>
              </tr>
              <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
        <!-- table container -->
        <a href="<?php echo e(url('/admin/add-banner')); ?>" class="btn btn-primary btn-block text-uppercase mb-3">Thêm banner chính</a>
      </div>
    </div>
    <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 tm-block-col">
      <div class="row tm-content-row">
        <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 tm-block-col">
          <div class="tm-bg-primary-dark tm-block tm-block-products">
            <h2 class="tm-block-title">Danh sách banner phụ 1</h2>
            <div class="tm-product-table-container">
              <table class="table table-hover tm-table-small tm-product-table">
                <thead>
                  <tr>
                    <th scope="col">&nbsp;</th>
                    <th scope="col" style="text-align: center">HÌNH</th>
                    <th scope="col" style="text-align: center">STATUS</th>
                    <th scope="col" style="text-align: center">NGÀY TẠO</th>
                    <th scope="col" style="text-align: center">NGÀY SỬA</th>
                    <th scope="col">&nbsp;</th>
                    <th scope="col">&nbsp;</th>
                  </tr>
                </thead>
                <tbody id="banner-1-body">
                  <?php if(count($banners) > 0): ?>
                  <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($banner->position_id == 2): ?>
                  <tr>
                    <th scope="row" style="padding-top: 25px;"><input type="checkbox" /></th>
                    <td class="product-img"><img src="<?php echo e(URL::to('/')); ?>/img/banner/<?= $banner->filename ?>" alt="" style="width: 80px; height: 80xp;"></td>
                    <td style="padding-top: 25px; text-align: center"><?php echo e($banner->status); ?></td>
                    <td style="padding-top: 25px; text-align: center"><?php echo e($banner->created_at); ?></td>
                    <td style="padding-top: 25px; text-align: center"><?php echo e($banner->updated_at); ?></td>
                    <td style="padding-top: 15px;">
                      <a href="<?php echo e(URL::to('/')); ?>/admin/edit-banner/<?= $banner->id ?>" class="tm-product-delete-link">
                        <i class="fas fa-pen tm-product-delete-icon"></i>
                      </a>
                    </td>
                    <td style="padding-top: 15px;">
                      <a href="javascript:" class="tm-product-delete-link">
                        <i class="far fa-trash-alt tm-product-delete-icon"></i>
                      </a>
                    </td>
                  </tr>
                  <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>
            <!-- table container -->
            <a href="<?php echo e(url('/admin/add-banner')); ?>" class="btn btn-primary btn-block text-uppercase mb-3">Thêm banner phụ thứ nhất</a>
          </div>
        </div>
        <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 tm-block-col">
          <div class="tm-bg-primary-dark tm-block tm-block-products">
            <h2 class="tm-block-title">Danh sách banner phụ 2</h2>
            <div class="tm-product-table-container">
              <table class="table table-hover tm-table-small tm-product-table">
                <thead>
                  <tr>
                    <th scope="col">&nbsp;</th>
                    <th scope="col" style="text-align: center">HÌNH</th>
                    <th scope="col" style="text-align: center">STATUS</th>
                    <th scope="col" style="text-align: center">NGÀY TẠO</th>
                    <th scope="col" style="text-align: center">NGÀY SỬA</th>
                    <th scope="col">&nbsp;</th>
                    <th scope="col">&nbsp;</th>
                  </tr>
                </thead>
                <tbody id="banner-1-body">
                  <?php if(count($banners) > 0): ?>
                  <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($banner->position_id == 3): ?>
                  <tr>
                    <th scope="row" style="padding-top: 25px;"><input type="checkbox" /></th>
                    <td class="product-img"><img src="<?php echo e(URL::to('/')); ?>/img/banner/<?= $banner->filename ?>" alt="" style="width: 80px; height: 80xp;"></td>
                    <td style="padding-top: 25px; text-align: center"><?php echo e($banner->status); ?></td>
                    <td style="padding-top: 25px; text-align: center"><?php echo e($banner->created_at); ?></td>
                    <td style="padding-top: 25px; text-align: center"><?php echo e($banner->updated_at); ?></td>
                    <td style="padding-top: 15px;">
                      <a href="<?php echo e(URL::to('/')); ?>/admin/edit-banner/<?= $banner->id ?>" class="tm-product-delete-link">
                        <i class="fas fa-pen tm-product-delete-icon"></i>
                      </a>
                    </td>
                    <td style="padding-top: 15px;">
                      <a href="javascript:" class="tm-product-delete-link">
                        <i class="far fa-trash-alt tm-product-delete-icon"></i>
                      </a>
                    </td>
                  </tr>
                  <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>
            <!-- table container -->
            <a href="<?php echo e(url('/admin/add-banner')); ?>" class="btn btn-primary btn-block text-uppercase mb-3">Thêm banner phụ thứ hai</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\project_main\resources\views/admin/pages/banner.blade.php ENDPATH**/ ?>