﻿
<?php $__env->startSection('content'); ?>
<div class="container mt-5">
  <?php if(session()->has('success')): ?>
  <div class="alert alert-success alert-posifixed">
    <?php echo e(session()->get('success')); ?>

  </div>
  <?php endif; ?>
  <div class="row tm-content-row">
    <div class="col-sm-12 col-md-12 col-lg-8 col-xl-8 tm-block-col">
      <div class="tm-bg-primary-dark tm-block tm-block-products">
        <h2 class="tm-block-title">Sản phẩm</h2>
        <div class="tm-product-table-container">
          <table class="table table-hover tm-table-small tm-product-table">
            <thead>
              <tr>
                <th scope="col">&nbsp;</th>
                <th scope="col">&nbsp;</th>
                <th scope="col">TÊN SẢN PHẨM</th>
                <th scope="col">GIÁ</th>
                <th scope="col">LOẠI SẢN PHẨM</th>
                <th scope="col">SỐ LƯỢNG</th>
                <th scope="col">&nbsp;</th>
              </tr>
            </thead>
            <tbody id="product-body">
              <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php $check = true ?>
              <tr>
                <th scope="row" style="padding-top: 50px;"><input value="<?= $item->id ?>"  class="deleteMulti" type="checkbox" /></th>
                <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($photo->product_id == $item->id && $photo->photo_feature == 1): ?>
                <?php $check = false ?>
                <td class="product-img"><img src="<?php echo e(URL::to('/')); ?>/img/image_sql/products/<?php echo e($photo->filename); ?>" alt="" style="width: 100px; height: 100px;"></td>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($check == true): ?>
                <td class="product-img"><img src="" alt="" style="width: 100px; height: 100px;"></td>
                <?php endif; ?>
                <td class="tm-product-name" data-id="<?php echo e($item->id); ?>" style="padding-top: 50px;"><?php echo e($item->name); ?></td>
                <td style="padding-top: 50px;"><?php echo e(number_format($item->price)); ?></td>
                <td style="padding-top: 50px;"><?php echo e($item->type_name); ?></td>
                <td style="padding-top: 50px;"><?php echo e($item->amount); ?></td>
                <td style="padding-top: 40px;">
                  <a onclick="deleteProduct(<?= $item->id ?>)" href="javascript:" class="tm-product-delete-link">
                    <i class="far fa-trash-alt tm-product-delete-icon"></i>
                  </a>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
        <!-- table container -->
        <a href="<?php echo e(url('/admin/add-product')); ?>" class="btn btn-primary btn-block text-uppercase mb-3">Thêm sản phẩm</a>
        <button onclick="deleteMulti()" class="btn btn-primary btn-block text-uppercase">
          Xoá sản phẩm được chọn
        </button>
      </div>
    </div>
    <div class="col-sm-12 col-md-12 col-lg-4 col-xl-4 tm-block-col">
      <div class="tm-bg-primary-dark tm-block tm-block-product-categories">
        <h2 class="tm-block-title">Loại sản phẩm</h2>
        <div class="tm-product-table-container">
          <table class="table tm-table-small tm-product-table">
            <tbody id="protype-body">
              <?php $__currentLoopData = $data['protype']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td style="padding-top: 20px;" class="tm-product-name" data-id="<?php echo e($item->type_id); ?>"><?php echo e($item->type_name); ?></td>
                <td class="text-center">
                  <a onclick="deleteProtype(<?= $item->type_id ?>)" href="javascript:" class="tm-product-delete-link">
                    <i class="far fa-trash-alt tm-product-delete-icon"></i>
                  </a>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
        <!-- table container -->
        <a href="<?php echo e(url('/admin/add-protype')); ?>" class="btn btn-primary btn-block text-uppercase mb-3">
          Thêm loại sản phẩm
        </a>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\project_main\resources\views/admin/pages/products.blade.php ENDPATH**/ ?>