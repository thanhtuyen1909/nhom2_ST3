﻿

<?php $__env->startSection('banner'); ?>
<div class="hero__item set-bg" data-setbg="img/hero/banner.jpg">
    <div class="hero__text">
        <span>THỰC PHẨM SẠCH</span>
        <h2>Rau củ <br />100% Organic</h2>
        <p>Miễn phí ship khi đạt giá trị đơn hàng từ 1.000.000 đồng</p>
        <a href="./shop-grid" class="primary-btn">MUA NGAY</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Categories Section Begin -->
<section class="categories">
    <div class="container">
        <div class="row">
            <div class="categories__slider owl-carousel">
                <?php $__currentLoopData = $data['protype']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3">
                    <div class="categories__item set-bg" data-setbg="img/image_sql/categories/<?= $value->type_img ?>">
                        <h5><a href="javascript:"><?= $value->type_name ?></a></h5>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>
<!-- Categories Section End -->

<!-- Featured Section Begin -->
<section class="featured spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-title">
                    <h2>Sản phẩm nổi bật</h2>
                </div>
                <div class="featured__controls">
                    <ul>
                        <li class="active" data-filter="*">All</li>
                        <li data-filter=".raucu">Rau củ</li>
                        <li data-filter=".fresh-meat">Thịt sạch</li>
                        <li data-filter=".haisan">Hải sản</li>
                        <li data-filter=".bovatrung">Bơ và Trứng</li>
                        <li data-filter=".traicayvahat">Trái cây và Hạt</li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="row featured__filter">
            <?php $__currentLoopData = $data['product']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($value->type_id == 4 && $value->feature == 1): ?>
            <div class="col-lg-3 col-md-4 col-sm-6 mix haisan">
                <div class="featured__item">
                    <div class="featured__item__pic set-bg" data-setbg="img/image_sql/products/<?= $value->filename ?>">
                        <ul class="featured__item__pic__hover">
                            <?php $temp = false; ?>
                            <?php if(Session::get('Login') != null): ?>
                            <?php $__currentLoopData = $data['check']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $check): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($check == $value->id): ?>
                            <li><a id="favourite<?= $value->id ?>" onclick="AddFavourite(<?= $value->id ?>)" href="javascript:" style="background-color: #7fad39;"><i class="fa fa-heart"></i></a></li>
                            <?php $temp = true; ?>
                            <?php break; ?>;
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($temp == false): ?>
                            <li><a id="favourite<?= $value->id ?>" onclick="AddFavourite(<?= $value->id ?>)" href="javascript:"><i class="fa fa-heart"></i></a></li>
                            <?php endif; ?>
                            <?php else: ?>
                            <li><a  href="<?php echo e(url('login')); ?>"><i class="fa fa-heart"></i></a></li>
                            <?php endif; ?>
                            <li><a href="javascript:"><i class="fa fa-retweet"></i></a></li>
                            <?php if(Session::get('Login') != null): ?>
                            <li><a onclick="AddCart(<?= $value->id ?>,1)" href="javascript:"><i class="fa fa-shopping-cart"></i></a></li>
                            <?php else: ?>
                            <li><a href="<?php echo e(url('login')); ?>"><i class="fa fa-shopping-cart"></i></a></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                    <div class="featured__item__text">
                        <h6><a href="<?php echo e(URL::to('/')); ?>/shop-details/<?php echo e($value->id); ?>"><?= $value->name ?></a></h6>
                        <h5><?= number_format($value->price) ?> VND</h5>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php $__currentLoopData = $data['product']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($value->type_id == 5 && $value->feature == 1): ?>
            <div class="col-lg-3 col-md-4 col-sm-6 mix bovatrung">
                <div class="featured__item">
                    <div class="featured__item__pic set-bg" data-setbg="img/image_sql/products/<?= $value->filename ?>">
                        <ul class="featured__item__pic__hover">
                        <?php $temp = false; ?>
                            <?php if(Session::get('Login') != null): ?>
                            <?php $__currentLoopData = $data['check']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $check): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($check == $value->id): ?>
                            <li><a id="favourite<?= $value->id ?>" onclick="AddFavourite(<?= $value->id ?>)" href="javascript:" style="background-color: #7fad39;"><i class="fa fa-heart"></i></a></li>
                            <?php $temp = true; ?>
                            <?php break; ?>;
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($temp == false): ?>
                            <li><a id="favourite<?= $value->id ?>" onclick="AddFavourite(<?= $value->id ?>)" href="javascript:"><i class="fa fa-heart"></i></a></li>
                            <?php endif; ?>
                            <?php else: ?>
                            <li><a  href="<?php echo e(url('login')); ?>"><i class="fa fa-heart"></i></a></li>
                            <?php endif; ?>
                            <li><a href="javascript:"><i class="fa fa-retweet"></i></a></li>
                            <?php if(Session::get('Login') != null): ?>
                            <li><a onclick="AddCart(<?= $value->id ?>,1)" href="javascript:"><i class="fa fa-shopping-cart"></i></a></li>
                            <?php else: ?>
                            <li><a href="<?php echo e(url('login')); ?>"><i class="fa fa-shopping-cart"></i></a></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                    <div class="featured__item__text">
                        <h6><a href="<?php echo e(URL::to('/')); ?>/shop-details/<?php echo e($value->id); ?>"><?= $value->name ?></a></h6>
                        <h5><?= number_format($value->price) ?> VND</h5>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php $__currentLoopData = $data['product']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($value->type_id == 3 && $value->feature == 1): ?>
            <div class="col-lg-3 col-md-4 col-sm-6 mix traicayvahat">
                <div class="featured__item">
                    <div class="featured__item__pic set-bg" data-setbg="img/image_sql/products/<?= $value->filename ?>">
                        <ul class="featured__item__pic__hover">
                        <?php $temp = false; ?>
                            <?php if(Session::get('Login') != null): ?>
                            <?php $__currentLoopData = $data['check']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $check): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($check == $value->id): ?>
                            <li><a id="favourite<?= $value->id ?>" onclick="AddFavourite(<?= $value->id ?>)" href="javascript:" style="background-color: #7fad39;"><i class="fa fa-heart"></i></a></li>
                            <?php $temp = true; ?>
                            <?php break; ?>;
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($temp == false): ?>
                            <li><a id="favourite<?= $value->id ?>" onclick="AddFavourite(<?= $value->id ?>)" href="javascript:"><i class="fa fa-heart"></i></a></li>
                            <?php endif; ?>
                            <?php else: ?>
                            <li><a  href="<?php echo e(url('login')); ?>"><i class="fa fa-heart"></i></a></li>
                            <?php endif; ?>
                            <li><a href="javascript:"><i class="fa fa-retweet"></i></a></li>
                            <?php if(Session::get('Login') != null): ?>
                            <li><a onclick="AddCart(<?= $value->id ?>,1)" href="javascript:"><i class="fa fa-shopping-cart"></i></a></li>
                            <?php else: ?>
                            <li><a href="<?php echo e(url('login')); ?>"><i class="fa fa-shopping-cart"></i></a></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                    <div class="featured__item__text">
                        <h6><a href="<?php echo e(URL::to('/')); ?>/shop-details/<?php echo e($value->id); ?>"><?= $value->name ?></a></h6>
                        <h5><?= number_format($value->price) ?> VND</h5>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php $__currentLoopData = $data['product']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($value->type_id == 1 && $value->feature == 1): ?>
            <div class="col-lg-3 col-md-3 col-sm-6 mix fresh-meat">
                <div class="featured__item">
                    <div class="featured__item__pic set-bg" data-setbg="img/image_sql/products/<?= $value->filename ?>">
                    <ul class="featured__item__pic__hover">
                    <?php $temp = false; ?>
                            <?php if(Session::get('Login') != null): ?>
                            <?php $__currentLoopData = $data['check']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $check): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($check == $value->id): ?>
                            <li><a id="favourite<?= $value->id ?>" onclick="AddFavourite(<?= $value->id ?>)" href="javascript:" style="background-color: #7fad39;"><i class="fa fa-heart"></i></a></li>
                            <?php $temp = true; ?>
                            <?php break; ?>;
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($temp == false): ?>
                            <li><a id="favourite<?= $value->id ?>" onclick="AddFavourite(<?= $value->id ?>)" href="javascript:"><i class="fa fa-heart"></i></a></li>
                            <?php endif; ?>
                            <?php else: ?>
                            <li><a  href="<?php echo e(url('login')); ?>"><i class="fa fa-heart"></i></a></li>
                            <?php endif; ?>
                            <li><a href="javascript:"><i class="fa fa-retweet"></i></a></li>
                            <?php if(Session::get('Login') != null): ?>
                            <li><a onclick="AddCart(<?= $value->id ?>,1)" href="javascript:"><i class="fa fa-shopping-cart"></i></a></li>
                            <?php else: ?>
                            <li><a href="<?php echo e(url('login')); ?>"><i class="fa fa-shopping-cart"></i></a></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                    <div class="featured__item__text">
                        <h6><a href="<?php echo e(URL::to('/')); ?>/shop-details/<?php echo e($value->id); ?>"><?= $value->name ?></a></h6>
                        <h5><?= number_format($value->price) ?> VND</h5>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php $__currentLoopData = $data['product']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($value->type_id == 2 && $value->feature == 1): ?>
            <div class="col-lg-3 col-md-4 col-sm-6 mix raucu">
                <div class="featured__item">
                    <div class="featured__item__pic set-bg" data-setbg="img/image_sql/products/<?= $value->filename ?>">
                        <ul class="featured__item__pic__hover">
                        <?php $temp = false; ?>
                            <?php if(Session::get('Login') != null): ?>
                            <?php $__currentLoopData = $data['check']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $check): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($check == $value->id): ?>
                            <li><a id="favourite<?= $value->id ?>" onclick="AddFavourite(<?= $value->id ?>)" href="javascript:" style="background-color: #7fad39;"><i class="fa fa-heart"></i></a></li>
                            <?php $temp = true; ?>
                            <?php break; ?>;
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($temp == false): ?>
                            <li><a id="favourite<?= $value->id ?>" onclick="AddFavourite(<?= $value->id ?>)" href="javascript:"><i class="fa fa-heart"></i></a></li>
                            <?php endif; ?>
                            <?php else: ?>
                            <li><a  href="<?php echo e(url('login')); ?>"><i class="fa fa-heart"></i></a></li>
                            <?php endif; ?>
                            <li><a href="javascript:"><i class="fa fa-retweet"></i></a></li>
                            <?php if(Session::get('Login') != null): ?>
                            <li><a onclick="AddCart(<?= $value->id ?>,1)" href="javascript:"><i class="fa fa-shopping-cart"></i></a></li>
                            <?php else: ?>
                            <li><a href="<?php echo e(url('login')); ?>"><i class="fa fa-shopping-cart"></i></a></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                    <div class="featured__item__text">
                        <h6><a href="<?php echo e(URL::to('/')); ?>/shop-details/<?php echo e($value->id); ?>"><?= $value->name ?></a></h6>
                        <h5><?= number_format($value->price) ?> VND</h5>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    </div>
</section>
<!-- Featured Section End -->

<!-- Banner Begin -->
<div class="banner">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6">
                <div class="banner__pic">
                    <img src="img/banner/banner-1.jpg" alt="banner 1">
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6">
                <div class="banner__pic">
                    <img src="img/banner/banner-1.jpg" alt="banner 2">
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Banner End -->

<!-- Latest Product Section Begin -->
<section class="latest-product spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6">
                <div class="latest-product__text">
                    <h4>Latest Products</h4>
                    <div class="latest-product__slider owl-carousel">
                        <div class="latest-prdouct__slider__item">
                            <?php $__currentLoopData = $data['proLast1']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(URL::to('/')); ?>/shop-details/<?php echo e($value->id); ?>" class="latest-product__item">
                                <div class="latest-product__item__pic">
                                    <img src="img/image_sql/products/<?= $value->filename; ?>" class="rounded-circle" style="width: 150px;" alt="">
                                </div>
                                <div class="latest-product__item__text">
                                    <h6><?= $value->name ?></h6>
                                    <span><?= number_format($value->price) ?> VND</span>
                                </div>
                            </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="latest-prdouct__slider__item">
                            <?php $__currentLoopData = $data['proLast2']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(URL::to('/')); ?>/shop-details/<?php echo e($value->id); ?>" class="latest-product__item">
                                <div class="latest-product__item__pic">
                                    <img src="img/image_sql/products/<?= $value->filename; ?>" class="rounded-circle" style="width: 150px;" alt="">
                                </div>
                                <div class="latest-product__item__text">
                                    <h6><?= $value->name ?></h6>
                                    <span><?= number_format($value->price) ?> VND</span>
                                </div>
                            </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-6">
                <div class="latest-product__text">
                    <h4>Top Rated Products</h4>
                    <div class="latest-product__slider owl-carousel">
                        <div class="latest-prdouct__slider__item">
                            <a href="javascript:" class="latest-product__item">
                                <div class="latest-product__item__pic">
                                    <img src="img/latest-product/lp-1.jpg" alt="">
                                </div>
                                <div class="latest-product__item__text">
                                    <h6>Crab Pool Security</h6>
                                    <span>$30.00</span>
                                </div>
                            </a>
                            <a href="javascript:" class="latest-product__item">
                                <div class="latest-product__item__pic">
                                    <img src="img/latest-product/lp-2.jpg" alt="">
                                </div>
                                <div class="latest-product__item__text">
                                    <h6>Crab Pool Security</h6>
                                    <span>$30.00</span>
                                </div>
                            </a>
                            <a href="javascript:" class="latest-product__item">
                                <div class="latest-product__item__pic">
                                    <img src="img/latest-product/lp-3.jpg" alt="">
                                </div>
                                <div class="latest-product__item__text">
                                    <h6>Crab Pool Security</h6>
                                    <span>$30.00</span>
                                </div>
                            </a>
                        </div>
                        <div class="latest-prdouct__slider__item">
                            <a href="javascript:" class="latest-product__item">
                                <div class="latest-product__item__pic">
                                    <img src="img/latest-product/lp-1.jpg" alt="">
                                </div>
                                <div class="latest-product__item__text">
                                    <h6>Crab Pool Security</h6>
                                    <span>$30.00</span>
                                </div>
                            </a>
                            <a href="javascript:" class="latest-product__item">
                                <div class="latest-product__item__pic">
                                    <img src="img/latest-product/lp-2.jpg" alt="">
                                </div>
                                <div class="latest-product__item__text">
                                    <h6>Crab Pool Security</h6>
                                    <span>$30.00</span>
                                </div>
                            </a>
                            <a href="javascript:" class="latest-product__item">
                                <div class="latest-product__item__pic">
                                    <img src="img/latest-product/lp-3.jpg" alt="">
                                </div>
                                <div class="latest-product__item__text">
                                    <h6>Crab Pool Security</h6>
                                    <span>$30.00</span>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</section>
<!-- Latest Product Section End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\project_6\resources\views/pages/home.blade.php ENDPATH**/ ?>