<?php if(Session::has("Cart") != null): ?>
<div class="select-items">
    <table>
        <tbody>
            <?php $__currentLoopData = Session::get("Cart")->product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="si-pic"><img class="img-cart" src="<?php echo e(URL::to('/')); ?>/img/image_sql/products/<?php echo e($item['productInfo']->filename); ?>" alt=""></td>
                <td class="si-text">
                    <div class="product-selected">
                        <p><?php echo e(number_format($item['productInfo']->price*(100-$item['productInfo']->sale)/100)); ?> VND x <?php echo e($item['quantity']); ?></p>
                        <h6><?php echo e($item['productInfo']->name); ?> </h6>
                    </div>
                </td>
                <td class="si-close">
                    <i class="fa fa-times" data-id="<?php echo e($item['productInfo']->id); ?>"></i>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<div class="select-total">
    <span>total:</span>
    <h5><?php echo e(number_format(Session::get("Cart")->totalPrice)); ?>₫</h5>
    <input hidden id="total-quantity-cart" type="number" value="<?php echo e(Session::get('Cart')->totalQuantity); ?>">
</div>
<div class="select-button">
    <a onclick="clearCart();" class="primary-btn view-card" style="cursor:pointer">XOÁ SẠCH</a>
</div>
<?php else: ?>
<div class="select-total">
    <span>total:</span>
    <h5>0 VND</h5>
    <input hidden id="total-quantity-cart" type="number" value="0">
</div>
<?php endif; ?><?php /**PATH C:\wamp64\www\project_main_1\resources\views//pages/cartInfo.blade.php ENDPATH**/ ?>