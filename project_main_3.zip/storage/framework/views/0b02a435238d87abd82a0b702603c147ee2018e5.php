<div class="row">
    <?php if(count($data['favourite']) > 0): ?>
    <?php $__currentLoopData = $data['favourite']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-lg-3 col-md-4 col-sm-6">
        <div class="product__item">
            <div class="product__item__pic set-bg">
                <img src="<?php echo e(URL::to('/')); ?>/img/image_sql/products/<?= $item['image'] ?>" alt="">
                <ul class="product__item__pic__hover">
                    <li><a onclick="DeleteFavourite(<?= $item['id'] ?>)" href="#"><i class="fa fa-heart"></i></a></li>
                    <li><a href="#"><i class="fa fa-retweet"></i></a></li>
                    <li><a href="javascript:"><i class="fa fa-shopping-cart"></i></a></li>
                </ul>
            </div>
            <div class="product__item__text">
                <h6><a href="./shop-details/<?php echo e($item['id']); ?>"><?php echo e($item['name']); ?></a></h6>
                <h5><?php echo e(number_format($item['price'])); ?> VND</h5>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
    <span> Không có sản phâm yêu thích </span>
    <?php endif; ?>
</div><?php /**PATH C:\wamp64\www\nhom2_ST3_1\resources\views//pages/listFavourite.blade.php ENDPATH**/ ?>