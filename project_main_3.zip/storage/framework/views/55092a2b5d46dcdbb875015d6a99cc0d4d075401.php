<?php if(count($banners) > 0): ?>
<?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($banner->position_id == 2): ?>
<tr>
    <th scope="row" style="padding-top: 25px;"><input type="checkbox" /></th>
    <td class="product-img"><img src="<?php echo e(URL::to('/')); ?>/img/banner/<?= $banner->filename ?>" alt="" style="width: 80px; height: 80xp;"></td>
    <td style="padding-top: 25px; text-align: center"><?php echo e($banner->status); ?></td>
    <td style="padding-top: 25px; text-align: center"><?php echo e($banner->created_at); ?></td>
    <td style="padding-top: 25px; text-align: center"><?php echo e($banner->updated_at); ?></td>
    <td style="padding-top: 15px;">
        <a href="<?php echo e(URL::to('/')); ?>/admin/edit-banner/<?= $banner->id ?>" class="tm-product-delete-link">
            <i class="fas fa-pen tm-product-delete-icon"></i>
        </a>
    </td>
    <td style="padding-top: 15px;">
        <a onclick="deleteBanner1(<?= $banner->id ?>)" href="javascript:" class="tm-product-delete-link">
            <i class="far fa-trash-alt tm-product-delete-icon"></i>
        </a>
    </td>
</tr>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH C:\wamp64\www\project_main_1\resources\views/admin/pages/listBanner1.blade.php ENDPATH**/ ?>