
<?php $__env->startSection('content'); ?>
<!-- Breadcrumb Section Begin -->
<?php if($data !=null): ?>
<section class="breadcrumb-section set-bg" data-setbg="img/breadcrumb.jpg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="breadcrumb__text">
                    <h2>Organi Shop</h2>
                    <div class="breadcrumb__option">
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                        <span>Shop</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Breadcrumb Section End -->

<!-- Product Section Begin -->
<section class="product spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-5">
                <div class="sidebar">
                    <div class="sidebar__item">
                        <h4>Loại sản phẩm</h4>
                        <ul>
                            <?php $__currentLoopData = $data['protype']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(URL::to('/')); ?>/classifiProduct/<?= $value->type_id ?>"><?php echo e($value->type_name); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>

                    <div class="sidebar__item">
                        <div class="latest-product__text">
                            <h4>Sản phẩm mới</h4>
                            <div class="latest-product__slider owl-carousel">
                                <div class="latest-prdouct__slider__item">
                                    <?php $__currentLoopData = $data['proLast1']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="#" class="latest-product__item">
                                        <div class="latest-product__item__pic">
                                            <img src="img/image_sql/products/<?= $value->filename ?>" alt="" style='width:100px'>
                                        </div>
                                        <div class="latest-product__item__text">
                                            <h6><?php echo e($value->name); ?></h6>
                                            <span><?php echo e($value->price); ?> VND</span>
                                        </div>
                                    </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="latest-prdouct__slider__item">
                                    <?php $__currentLoopData = $data['proLast2']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="#" class="latest-product__item">
                                        <div class="latest-product__item__pic">
                                            <img src="img/image_sql/products/<?= $value->filename ?>" alt="" style='width:100px'>
                                        </div>
                                        <div class="latest-product__item__text">
                                            <h6><?php echo e($value->name); ?></h6>
                                            <span><?php echo e($value->price); ?></span>
                                        </div>
                                    </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-9 col-md-7">
                <div class="product__discount" style="border-bottom: 4px solid #7fad39;">
                    <div class="section-title product__discount__title">
                        <h2>Sản phẩm đang được giảm giá</h2>
                    </div>
                    <div class="row">
                        <div class="product__discount__slider owl-carousel">
                            <?php $__currentLoopData = $data['saleProduct']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($value->sale > 0): ?>
                            <div class="col-lg-4">
                                <div class="product__discount__item">
                                    <div class="product__discount__item__pic set-bg" data-setbg="img/image_sql/products/<?= $value->filename ?>">
                                        <div class="product__discount__percent">-<?php echo e($value->sale); ?>%</div>
                                        <ul class="product__item__pic__hover">
                                            <?php $temp = false; ?>
                                            <?php if(Session::get('Login') != null): ?>
                                            <?php $__currentLoopData = $data['check']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $check): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($check == $value->id): ?>
                                            <li><a id="favourite<?= $value->id ?>" onclick="AddFavourite(<?= $value->id ?>)" href="javascript:" style="background-color: #7fad39;"><i class="fa fa-heart"></i></a></li>
                                            <?php $temp = true; ?>
                                            <?php break; ?>;
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($temp == false): ?>
                                            <li><a id="favourite<?= $value->id ?>" onclick="AddFavourite(<?= $value->id ?>)" href="javascript:"><i class="fa fa-heart"></i></a></li>
                                            <?php endif; ?>
                                            <?php else: ?>
                                            <li><a href="<?php echo e(url('login')); ?>"><i class="fa fa-heart"></i></a></li>
                                            <?php endif; ?>
                                            <li><a href="javascript:"><i class="fa fa-retweet"></i></a></li>
                                            <?php if(Session::get('Login') != null): ?>
                                            <li><a onclick="AddCart(<?= $value->id ?>,1)" href="javascript:"><i class="fa fa-shopping-cart"></i></a></li>
                                            <?php else: ?>
                                            <li><a href="<?php echo e(url('login')); ?>"><i class="fa fa-shopping-cart"></i></a></li>
                                            <?php endif; ?>
                                        </ul>
                                    </div>
                                    <div class="product__discount__item__text">
                                        <span><?php echo e($value->type_name); ?></span>
                                        <h5><a href="<?php echo e(URL::to('/')); ?>/shop-details/<?php echo e($value->id); ?>"><?php echo e($value->name); ?></a></h5>
                                        <div class="product__item__price"><?php echo e(number_format($value->price*(100-$value->sale)/100)); ?> VND <span><?php echo e(number_format($value->price)); ?> VND</span></div>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <div class="section-title product__discount__title" style="text-align: center; padding-top: 30px">
                    <h4>Danh sách sản phẩm</h4>
                </div>
                <div class="row">
                    <?php $__currentLoopData = $data['product']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6 col-sm-6">
                        <div class="product__item">
                            <div class="product__item__pic set-bg" data-setbg="img/image_sql/products/<?= $value->filename ?>">
                                <?php if($value->sale > 0): ?>
                                <div class="product__discount__percent">-<?php echo e($value->sale); ?>%</div>
                                <?php endif; ?>
                                <ul class="product__item__pic__hover">
                                    <?php $temp = false; ?>
                                    <?php if(Session::get('Login') != null): ?>
                                    <?php $__currentLoopData = $data['check']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $check): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($check == $value->id): ?>
                                    <li><a id="favourite<?= $value->id ?>" onclick="AddFavourite(<?= $value->id ?>)" href="javascript:" style="background-color: #7fad39;"><i class="fa fa-heart"></i></a></li>
                                    <?php $temp = true; ?>
                                    <?php break; ?>;
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($temp == false): ?>
                                    <li><a id="favourite<?= $value->id ?>" onclick="AddFavourite(<?= $value->id ?>)" href="javascript:"><i class="fa fa-heart"></i></a></li>
                                    <?php endif; ?>
                                    <?php else: ?>
                                    <li><a href="<?php echo e(url('login')); ?>"><i class="fa fa-heart"></i></a></li>
                                    <?php endif; ?>
                                    <li><a href="javascript:"><i class="fa fa-retweet"></i></a></li>
                                    <?php if(Session::get('Login') != null): ?>
                                    <li><a onclick="AddCart(<?= $value->id ?>,1)" href="javascript:"><i class="fa fa-shopping-cart"></i></a></li>
                                    <?php else: ?>
                                    <li><a href="<?php echo e(url('login')); ?>"><i class="fa fa-shopping-cart"></i></a></li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                            <div class="product__item__text">
                                <h6><a href="<?php echo e(URL::to('/')); ?>/shop-details/<?php echo e($value->id); ?>"><?php echo e($value->name); ?></a></h6>
                                <?php if($value->sale > 0): ?>
                                <div class="product__item__price"><?php echo e(number_format($value->price*(100-$value->sale)/100)); ?> VND <span><?php echo e(number_format($value->price)); ?> VND</span></div>
                                <?php else: ?>
                                <h5><?php echo e(number_format($value->price*(100-$value->sale)/100)); ?> VND</h5>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="product__pagination">
                    <a href="#">1</a>
                    <a href="#">2</a>
                    <a href="#">3</a>
                    <a href="#"><i class="fa fa-long-arrow-right"></i></a>
                </div>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>
<!-- Product Section End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\project_6\resources\views//pages/shop-grid.blade.php ENDPATH**/ ?>