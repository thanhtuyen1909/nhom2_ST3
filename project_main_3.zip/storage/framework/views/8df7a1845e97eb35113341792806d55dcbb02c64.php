
<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row tm-content-row">
        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 tm-block-col">
            <div class="tm-bg-primary-dark tm-block tm-block-products">
                <h2 class="tm-block-title">Đơn hàng</h2>
                <div class="tm-product-table-container">
                    <table class="table table-hover tm-table-small tm-product-table">
                        <thead>
                            <tr>
                                <th scope="col" style="text-align: center">MÃ ĐƠN</th>
                                <th scope="col" style="text-align: center">USERNAME</th>
                                <th scope="col" style="text-align: center">TRẠNG THÁI</th>
                                <th scope="col" style="text-align: center">GIÁ TRỊ ĐƠN</th>
                                <th scope="col" style="text-align: center">NGÀY TẠO ĐƠN</th>
                            </tr>
                        </thead>
                        <tbody id="order-body">
                            <?php $__currentLoopData = $dataArray1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td style="text-align: center" class="tm-product-name" data-id="<?php echo e($value['maDH']); ?>">#<?php echo e($value['maDH']); ?></td>
                                <td style="text-align: center"><?php echo e($value['username']); ?></td>
                                <td style="text-align: center">
                                    <?php if($value['status'] == "Đã nhận"): ?>
                                    <div class="tm-status-circle moving">
                                        <?php elseif($value['status'] == "Đã huỷ"): ?>
                                        <div class="tm-status-circle cancelled">
                                            <?php else: ?>
                                            <div class="tm-status-circle pending">
                                                <?php endif; ?>
                                            </div><?php echo e($value['status']); ?>

                                </td>
                                <td style="text-align: center"><?php echo e(number_format($value['totalPrice'])); ?> VND</td>
                                <td style="text-align: center"><?php echo e($value['created_at']); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\project_main_3\resources\views/admin/pages/listDonHang.blade.php ENDPATH**/ ?>