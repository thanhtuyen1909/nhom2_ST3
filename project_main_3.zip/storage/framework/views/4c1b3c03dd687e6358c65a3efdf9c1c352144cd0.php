<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .container {
            width: 70%;
            margin: auto;
            text-align: center;
        }

        /* Định dạng phần form đăng nhập*/
        .fomrgroup {
            width: 50%;
            margin: auto;
            display: block;
            height: 50px;
        }

        .fomrgroup input {
            float: right;
            width: 70%;
            height: 25px;
            margin-right: 20px;
            line-height: 50px;
        }

        .fomrgroup b {
            font-size: 20px;
        }

        /* The Modal (background) */
        .modal {
            display: none;
            /* mặc định được ẩn đi */
            position: fixed;
            /* vị trí cố định */
            z-index: 1;
            /* Ưu tiên hiển thị trên cùng */
            padding-top: 100px;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgb(0, 0, 0);
            background-color: rgba(0, 0, 0, 0.4);
        }

        /* Modal Content */
        .modal-content {
            background-color: #fefefe;
            margin: auto;
            padding: 20px;
            border: 1px solid #888;
            width: 60%;
        }

        /* The Close Button */
        .close {
            color: #aaaaaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: #000;
            text-decoration: none;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <div class="container">

        <h2>Freetuts.net hướng dẫn tạo Modal Box</h2>

        <!-- Button đăng nhập để mở form đăng nhập -->
        <button id="myBtn">Đăng Nhập</button>

        <!-- The Modal -->
        <div id="myModal" class="modal">
            <!-- Nội dung form đăng nhập -->
            <div class="modal-content">
                <form action="#">
                    <span class="close">&times;</span>
                    <h2>ĐÁNH GIÁ SẢN PHẨM</h2>
                    <div class="fomrgroup">
                        <ul style="list-style: none; display: flex;">
                            <li style="font-size: 20px; line-height: 45px; padding-right: 100px;">Sản phẩm 1</li>
                            <?php for($count = 1; $count <=5; $count++): ?> <li title="đánh giá sao" id="" data-index="" data-product_id="" data_rating="" class="rating" style="cursor: pointer; color:#ccc; font-size: 30px;">
                                &#9733;
                                </li>
                                <?php endfor; ?>
                        </ul>
                    </div>
                    <div class="fomrgroup">
                        <button>Đăng nhập</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script>
        // lấy phần Modal
        var modal = document.getElementById('myModal');

        // Lấy phần button mở Modal
        var btn = document.getElementById("myBtn");

        // Lấy phần span đóng Modal
        var span = document.getElementsByClassName("close")[0];

        // Khi button được click thi mở Modal
        btn.onclick = function() {
            modal.style.display = "block";
        }

        // Khi span được click thì đóng Modal
        span.onclick = function() {
            modal.style.display = "none";
        }

        // Khi click ngoài Modal thì đóng Modal
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }
    </script>
</body>

</html><?php /**PATH C:\wamp64\www\project_main_2\resources\views/pages/listProductsRating.blade.php ENDPATH**/ ?>