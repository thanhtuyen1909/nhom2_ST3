
<?php $__env->startSection('content'); ?>
<!-- Breadcrumb Section Begin -->
<section class="breadcrumb-section set-bg" data-setbg="img/breadcrumb.jpg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="breadcrumb__text">
                    <h2>Thanh toán</h2>
                    <div class="breadcrumb__option">
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                        <span>Thanh toán</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Breadcrumb Section End -->

<!-- Checkout Section Begin -->
<section class="checkout spad">
    <div class="container">
        <div class="checkout__form">
            <h4>Thông tin nhận hàng</h4>
            <form action="<?php echo e(URL::to('/')); ?>/checkout" method="POST">
                <div class="row">
                    <div class="col-lg-8 col-md-6">
                        <div class="checkout__input">
                            <p>Họ & Tên <span>*</span></p>
                            <input type="text" placeholder="Điền Họ & Tên" require name="hoTen">
                        </div>
                        <div class="checkout__input">
                            <p>Số điện thoại <span>*</span></p>
                            <input type="text" placeholder="Điền số điện thoại" require name="soDT">
                        </div>
                        <div class="checkout__input">
                            <p>Địa chỉ giao hàng <span>*</span></p>
                            <input type="text" placeholder="Điền địa chỉ giao hàng" require name="diaChi">
                        </div>
                        <div class="checkout__input">
                            <p>Ghi chú</p>
                            <textarea name="" id="" cols="90" rows="3" placeholder="Lưu ý..." name="note"></textarea>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="checkout__order">
                            <h4>Danh sách mặt hàng</h4>
                            <div class="checkout__order__products">Sản phẩm <span>Tổng tiền</span></div>
                            <ul>
                            <?php if(isset(Session::get("Cart")->product)): ?>
                            <?php $__currentLoopData = Session::get("Cart")->product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($item['productInfo']->name); ?> <span><?php echo e(number_format($item['productInfo']->price)); ?> VND</span></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            </ul>
                            <?php if(isset(Session::get("Cart")->product)): ?>
                            <div class="checkout__order__total">Tổng cộng <span><?php echo e(number_format(Session::get("Cart")->totalPrice)); ?> VND</span></div>
                            <?php endif; ?>
                            <div class="checkout__order__total">Tổng cộng <span>0 VND</span></div>
                            <p>Sau khi đặt hàng thành công chúng tôi sẽ liên hệ xác nhận đơn hàng với quý khách trước khi đơn hàng được chuyển đi.</p>
                            <button type="submit" class="site-btn">Đặt hàng</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</section>
<!-- Checkout Section End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\project_3\resources\views/pages/checkout.blade.php ENDPATH**/ ?>